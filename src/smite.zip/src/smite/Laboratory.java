package smite;

import battlecode.common.*;

public class Laboratory extends Robot {

    public Laboratory(RobotController rc) throws GameActionException {
        super(rc);
    }

    @Override
    public void runUnit() throws GameActionException { 
    }
}
